package model;

import model.Obra;

public class Pintura extends Obra {

    public String tecnica;

    /*
    public Pintura(String nome, String autor, int ano, String tecnica){
        this.setNome(nome);
        this.setAutor(autor);
        this.setAno(ano);
        this.tecnica = tecnica;
    }
*/
    public Pintura() {

    }

    @Override
    public void mostraInfo(){
        super.mostraInfo();
        System.out.println("Técnica: " + this.tecnica);
    }

    public String getTecnica() {
        return tecnica;
    }

    public void setTecnica(String tecnica) {
        this.tecnica = tecnica;
    }
}
