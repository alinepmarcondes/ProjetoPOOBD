package model;

public class Escultura extends Obra {

    private String material;

    /*
    public Escultura(String nome, String autor, int ano, String material){
        this.setNome(nome);
        this.setAutor(autor);
        this.setAno(ano);
        this.material = material;
    }
*/

    public Escultura() {
    }

    @Override
    public void mostraInfo(){
        super.mostraInfo();
        System.out.println("Material: " + this.material);
    }

    public String getMaterial() {
        return material;
    }

    public void setMaterial(String material) {
        this.material = material;
    }
}
