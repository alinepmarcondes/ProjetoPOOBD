package model;

import dao.PinturaDAO;

public class Principal {
    public static void main(String[] args) {

        PinturaDAO iDAO = new PinturaDAO();
        Pintura p1 = new Pintura();
        p1.setNome("Pintura 1");
        p1.setAutor("Autor 1");
        p1.setAno(1900);
        p1.setTecnica("Óleo sobre tela");

        iDAO.inserirPintura(p1);
        /*
        //inserir--------------------------
        if(iDAO.inserirPintura(p1)){
            System.out.println("Pintura inserido");
        }
        else{
            System.out.println("Alguma coisa n rolou");
        }
*/

    }
}
